package com.hibernate.Demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="parentDetails")

public class Parent {
	@Id
	private int p_id;
	private String pName;
	private Child chv;
	public Parent() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Parent(int p_id, String pName, Child chv) {
		super();
		this.p_id = p_id;
		this.pName = pName;
		this.chv = chv;
	}
	public int getP_id() {
		return p_id;
	}
	public void setP_id(int p_id) {
		this.p_id = p_id;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public Child getChv() {
		return chv;
	}
	public void setChv(Child chv) {
		this.chv = chv;
	}
	
	@Override
	public String toString() {
		return "Parent [p_id=" + p_id + ", pName=" + pName + ", chv=" + chv + "]";
	}
	
	

}
