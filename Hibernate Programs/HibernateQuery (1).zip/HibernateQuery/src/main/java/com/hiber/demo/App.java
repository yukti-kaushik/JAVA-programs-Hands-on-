package com.hiber.demo;


import java.util.Iterator;
import java.util.List;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class App 
{
    public static void main( String[] args )
    {
    	Session session=HibernateUtil.getSessionFactory().openSession();
    	Transaction tx=session.beginTransaction();
    	
		
		/*
		 * Employee emp= new Employee(); emp.setName("gokarn"); emp.setSalary(40000);
		 * emp.setJob("HR");
		 * 
		 * session.save(emp); System.out.println("add hua");
		 */
		 
       
        
		
		  TypedQuery query=session.getNamedQuery("findEmployeeByName");
		 
		  query.setParameter("name", "gokarn");
		  
		  List<Employee> employees=query.getResultList(); 
		  Iterator<Employee> itr=employees.iterator();
		  while(itr.hasNext()) 
		  { 
			  Employee e=itr.next();
		      System.out.println(e); 
		  }
		 
    	tx.commit();
    	session.close();
    }
}
