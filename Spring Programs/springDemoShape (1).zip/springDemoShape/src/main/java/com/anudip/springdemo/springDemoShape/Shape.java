package com.anudip.springdemo.springDemoShape;

public interface Shape {
	void draw();
}
