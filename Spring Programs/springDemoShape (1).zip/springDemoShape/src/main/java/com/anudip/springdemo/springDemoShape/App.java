package com.anudip.springdemo.springDemoShape;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("springConfig.xml");
    	Painter painter1=(Painter) context.getBean("tejas");
    	painter1.perform();
    }
}
