package com.anudip.springdemo.springDemoShape;

public class Painter implements Performer {
	
	Shape shape;
	
	@Override
	public void perform() {
		shape.draw();
		
	}

	public Painter(Shape shape) {
		super();
		this.shape = shape;
	}
	
}
