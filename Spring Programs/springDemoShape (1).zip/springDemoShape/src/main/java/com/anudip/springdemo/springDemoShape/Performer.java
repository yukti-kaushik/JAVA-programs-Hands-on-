package com.anudip.springdemo.springDemoShape;

public interface Performer {
	void perform();
}
