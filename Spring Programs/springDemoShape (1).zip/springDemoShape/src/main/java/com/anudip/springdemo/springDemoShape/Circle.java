package com.anudip.springdemo.springDemoShape;

public class Circle implements Shape {

	@Override
	public void draw() {
		System.out.println("it will draw Circle");
		
	}
	
}
