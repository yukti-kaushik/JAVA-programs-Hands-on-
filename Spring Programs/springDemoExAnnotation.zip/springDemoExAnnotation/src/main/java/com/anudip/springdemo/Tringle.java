package com.anudip.springdemo;

import org.springframework.stereotype.Component;
// component that allows annotation that allows Spring to detect our custom beans automatically
// <bean id="tri" class="com.anudip.springdemo.Tringle"></bean>
@Component("tri")
public class Tringle implements Shape {
	
	String color="Red";
	
	public Tringle() {
		super();
	}

	public Tringle(String color) {
		super();
		this.color = color;
	}

	@Override
	public void draw() {
		System.out.println("Painter is Drawing "+color+" Colour Triangle");
	}
}
