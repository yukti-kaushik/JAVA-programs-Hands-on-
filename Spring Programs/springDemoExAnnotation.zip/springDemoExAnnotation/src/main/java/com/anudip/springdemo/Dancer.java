package com.anudip.springdemo;

import org.springframework.stereotype.Component;
// <bean id="Ajay" class="com.anudip.springdemo.Dancer"></bean>
@Component("tejas")
public class Dancer implements Performer {

	@Override
	public void perform() {
		System.out.println("Danser is dancing on Bado Badi Song");
	}
}
