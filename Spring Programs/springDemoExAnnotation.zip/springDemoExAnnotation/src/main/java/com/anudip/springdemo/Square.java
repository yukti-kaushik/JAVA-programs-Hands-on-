package com.anudip.springdemo;

import org.springframework.stereotype.Component;
//<bean id="sqr" class="com.anudip.springdemo.Square"></bean>
@Component("sqr")
public class Square implements Shape {
	
	public Square() {
		super();
	}

	@Override
	public void draw() {
		System.out.println("Drawing a Square");
	}
	
}
