package com.anudip.springdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

// There are two ways to inject the objects
// 1. Constructor Way
// 2. Setter Way
//<bean id="Raviraj" class="com.anudip.springdemo.Painter"></bean>

@Component("Raviraj")
public class Painter implements Performer {
	@Autowired
	@Qualifier("sqr")
	Shape shape;

	public Painter() {
		super();
	}

	public Painter(Shape shape) {
		super();
		this.shape = shape;
	}

	@Override
	public void perform() {
		shape.draw();
	}
}
