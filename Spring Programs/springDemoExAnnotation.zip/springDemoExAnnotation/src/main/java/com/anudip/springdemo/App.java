package com.anudip.springdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

// IOC Contaner - Dependancy Injection (Two Way 1. Constructor & Setter)
//interface BeanFactory
//{
//	
//}
//interface AppliactionContext extends BeanFactory
//{
//	
//}
//class ClassPathXmlApplicationContext implements ApplicationContext
//{
//	
//}

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("shape.xml");
    	Painter p=(Painter) context.getBean("Raviraj");
    	p.perform();
    	
//    	Performer p=(Performer) context.getBean("Saurabh");
//    	p.perform();
    }
}
