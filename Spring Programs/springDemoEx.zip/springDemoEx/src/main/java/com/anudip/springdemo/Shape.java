package com.anudip.springdemo;

public interface Shape {
	void draw();
}
