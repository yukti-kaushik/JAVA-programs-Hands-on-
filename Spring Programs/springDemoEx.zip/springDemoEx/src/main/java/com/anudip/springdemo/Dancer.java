package com.anudip.springdemo;

public class Dancer implements Performer {

	@Override
	public void perform() {
		System.out.println("Danser is dancing on Bado Badi Song");
	}
}
