package com.anudip.springdemo;

public class Tringle implements Shape {
	
	String color;
	
	public Tringle(String color) {
		super();
		this.color = color;
	}

	@Override
	public void draw() {
		System.out.println("Painter is Drawing "+color+" Colour Triangle");
	}
}
