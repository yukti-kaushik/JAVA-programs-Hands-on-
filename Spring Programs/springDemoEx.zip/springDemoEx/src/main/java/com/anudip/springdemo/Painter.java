package com.anudip.springdemo;
// There are two ways to inject the objects
// 1. Constructor Way
// 2. Setter Way
public class Painter implements Performer {
	
	Shape shape;

	public Painter(Shape shape) {
		super();
		this.shape = shape;
	}

	@Override
	public void perform() {
		shape.draw();
	}
}
