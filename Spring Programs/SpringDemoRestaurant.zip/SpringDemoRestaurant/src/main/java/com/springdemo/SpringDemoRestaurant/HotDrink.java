package com.springdemo.SpringDemoRestaurant;

public interface HotDrink 
{
	public void prepareHotDrink();
}
