package com.springdemo.SpringDemoRestaurant;

public class Tea implements HotDrink
{
	public void prepareHotDrink() 
	{
		System.out.println("Hi... I am making tea for you");
	}
}
