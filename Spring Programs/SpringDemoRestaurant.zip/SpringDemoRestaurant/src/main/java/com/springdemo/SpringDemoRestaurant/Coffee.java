package com.springdemo.SpringDemoRestaurant;

public class Coffee implements HotDrink
{
	public void prepareHotDrink() 
	{
		System.out.println("Hi... I am making Coffee for you");
	}
}
