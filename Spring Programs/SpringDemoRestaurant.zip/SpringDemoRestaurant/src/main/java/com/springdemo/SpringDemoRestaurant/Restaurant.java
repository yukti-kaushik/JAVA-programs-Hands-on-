package com.springdemo.SpringDemoRestaurant;

public class Restaurant 
{
	HotDrink hotDrink;
	
	String welcomeNote;
	
//	public Restaurant(HotDrink hotDrink)
//	{
//		this.hotDrink=hotDrink;
//	}
	
	public String getWelcomeNote() {
		return welcomeNote;
	}

	public void setWelcomeNote(String welcomeNote) {
		this.welcomeNote = welcomeNote;
	}

	public Restaurant(HotDrink hotDrink) 
	{
		super();
		this.hotDrink = hotDrink;
	}
	
	void prepareDrink()
	{
		hotDrink.prepareHotDrink();
	}
	
	void greetCustomer()
	{
		System.out.println(welcomeNote);
	}

}
