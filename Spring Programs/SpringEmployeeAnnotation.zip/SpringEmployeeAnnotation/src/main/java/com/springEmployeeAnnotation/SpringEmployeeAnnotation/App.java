package com.springEmployeeAnnotation.SpringEmployeeAnnotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext context=new ClassPathXmlApplicationContext("employee.xml");
    	Employee employee=(Employee) context.getBean("Vijay");
    	employee.work();
//    	Developer p=(Developer) context.getBean("dev");
//    	p.work();
//    	
//    	Manager q=(Manager) context.getBean("Vijay");
//    	q.work();
//    	
//    	Tester r=(Tester) context.getBean("Ajay");
//    	r.work();    	
    }
}
