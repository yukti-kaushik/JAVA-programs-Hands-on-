package com.springEmployeeAnnotation.SpringEmployeeAnnotation;

public interface Employee {
	void work();
}
