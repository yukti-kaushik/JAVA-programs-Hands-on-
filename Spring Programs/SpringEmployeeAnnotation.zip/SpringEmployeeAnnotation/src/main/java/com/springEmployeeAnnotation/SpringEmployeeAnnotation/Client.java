package com.springEmployeeAnnotation.SpringEmployeeAnnotation;

public interface Client {
	void project();
}
