package com.springEmployeeAnnotation.SpringEmployeeAnnotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("Vijay")
public class Manager implements Employee {
	
	@Autowired
	@Qualifier("axix")
	//Employee emp;
	Client cli;
	
	public Manager() {
		super();
	}

	@Override
	public void work() {
		cli.project();
	}
	
	
	public Manager(Employee emp) {
		super();
		this.cli = cli;
	}
	
}
