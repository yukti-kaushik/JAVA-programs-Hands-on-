package com.springEmployeeAnnotation.SpringEmployeeAnnotation;

import org.springframework.stereotype.Component;

@Component("Ajay")
public class Tester implements Employee {

	public Tester() {
		super();
	}

	@Override
	public void work() {
		System.out.println("Tester tests projects...");
	}
}
