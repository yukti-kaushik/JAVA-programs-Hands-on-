package com.springEmployeeAnnotation.SpringEmployeeAnnotation;

import org.springframework.stereotype.Component;

@Component("axix")
public class AxixBank implements Client {

	String empType;
	@Override
	public void project() {
		System.out.println("The Employee is working for Axix Bank Project");
		
	}

}
