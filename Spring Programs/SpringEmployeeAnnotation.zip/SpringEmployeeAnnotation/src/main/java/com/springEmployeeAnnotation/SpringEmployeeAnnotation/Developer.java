package com.springEmployeeAnnotation.SpringEmployeeAnnotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component("dev")
public class Developer implements Employee {

	@Autowired
	@Qualifier("dev")
	Employee emp;
	
	public Developer() {
		super();
	}

	@Override
	public void work() {
		System.out.println("Developer develope projects...");
	}

	public Developer(Employee emp) {
		super();
		this.emp = emp;
	}
	
	
}
