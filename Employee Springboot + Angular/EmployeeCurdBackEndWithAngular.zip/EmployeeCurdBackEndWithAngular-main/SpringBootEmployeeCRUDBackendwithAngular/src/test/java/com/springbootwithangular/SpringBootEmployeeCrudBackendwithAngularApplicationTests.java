package com.springbootwithangular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEmployeeCrudBackendwithAngularApplicationTests {

	@Test
	void contextLoads() {
	}

}
