package com.springbootwithangular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmployeeCrudBackendwithAngularApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmployeeCrudBackendwithAngularApplication.class, args);
	}

}
